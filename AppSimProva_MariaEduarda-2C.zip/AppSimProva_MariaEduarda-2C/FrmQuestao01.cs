﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MariaEduarda_2C
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os elementos na tela
            float preco1 = float.Parse(txtPreco01.Text);
            float preco2 = float.Parse(txtPreco02.Text);
            float preco3 = float.Parse(txtPreco03.Text);

            //Variável para guardar total da compra
            float totalCompra;

            //Cálculo do total
            totalCompra = preco1 + preco2 + preco3;

            //Mostrar os result5ados das parcelas
            lblResult1Parc.Text = (totalCompra / 1).ToString("C");
            lblResult2Parc.Text = (totalCompra / 2).ToString("C");
            lblResult3Parc.Text = (totalCompra / 3).ToString("C");
            lblResult4Parc.Text = (totalCompra / 4).ToString("C");
            lblResult5Parc.Text = (totalCompra / 5).ToString("C");



        }
    }
}
