﻿// See https://aka.ms/new-console-template for more information

int anoNascimento = int.Parse(Console.ReadLine());

