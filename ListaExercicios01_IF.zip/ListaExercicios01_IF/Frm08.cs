﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm08 : Form
    {
        public Frm08()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string opcao = txtOpcao.Text;

            switch (opcao)
            {
                case "F":
                    MessageBox.Show("Sexo Feminino.");
                    break;
                default:
                    MessageBox.Show("Sexo Inválido, pois é um projeto de mulheres.");
                    break;
            }
        }
    }
}
