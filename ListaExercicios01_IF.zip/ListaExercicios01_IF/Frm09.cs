﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm09 : Form
    {
        public Frm09()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float valor = float.Parse(txtValor.Text);

            if(valor == 0)
            {
                MessageBox.Show("O valor é neutro ou positivo.");
            }
            else if (valor > 0)
            {
                MessageBox.Show("O valor é positivo.");
            }
            else 
            {
                MessageBox.Show("O valor é negativo.");
            }
        }
    }
}
