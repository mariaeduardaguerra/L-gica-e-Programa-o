﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm11 : Form
    {
        public Frm11()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float prcProduto = float.Parse(txtPrcProduto.Text);
            string condPag = txtCondPag.Text;
            float resultado;

            if (condPag == "Dinheiro" || condPag ==  "Cheque")
            {
                resultado = prcProduto - (prcProduto * 10 / 100);
                MessageBox.Show("O valor a pagar é " + resultado);
            }

            else if (condPag == "Cartão de Crédito")
            {
                resultado = prcProduto - (prcProduto * 15 / 100);
                MessageBox.Show("O valor a pagar é " + resultado);
            }

            else if (condPag == "Em duas vezes s/juros")
            {
                resultado = prcProduto/2;
                MessageBox.Show("O valor a pagar é " + resultado);
            }

            else if (condPag == "Em duas vezes com juros")
            {
                resultado = prcProduto - (prcProduto * 10 / 100);
                MessageBox.Show("O valor a pagar é " + resultado);
            }

            else
            {
                MessageBox.Show("Condição de pagamento inválida");
            }
        }
    }
}
