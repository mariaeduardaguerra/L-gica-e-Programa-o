﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm05 : Form
    {
        public Frm05()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float vlrLanche = float.Parse(txtValorLanche.Text);
            float vlrPago = float.Parse(txtValorPago.Text);
            float resultado;

            resultado = vlrPago - vlrLanche;

            if (resultado >=0)
            {
                MessageBox.Show("Há um troco de " + resultado);
            }
            else
            {
                MessageBox.Show("Não foi possível realizar a compra!");
            }


        }
    }
}
