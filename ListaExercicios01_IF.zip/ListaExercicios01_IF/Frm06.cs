﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm06 : Form
    {
        public Frm06()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            int numLados = int.Parse(txtNumLados.Text);

            switch (numLados)
            {
                case 3:
                 MessageBox.Show("Triângulo");
                  break;
                case 4:
                 MessageBox.Show("Quadrado");
                  break;
                default:
                 MessageBox.Show("Opção Inválida!");
                  break;
            }
        }

        private void lblNumLados_Click(object sender, EventArgs e)
        {

        }
    }
}
