﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm10 : Form
    {
        public Frm10()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(txtPeso.Text);
            float altura = float.Parse(txtAltura.Text);
            float resultado;

            resultado = peso / (altura * altura);

            if (resultado < 18.5f)
            {
                MessageBox.Show("Abaixo do peso ideal!");
            }
            else if (resultado >= 18.5f && resultado <= 25)
            {
                MessageBox.Show("No peso ideal!");
            }
            else if (resultado > 25 && resultado <= 30)
            {
                MessageBox.Show("Acima do peso ideal!");
            }
            else if (resultado > 30)
            {
                MessageBox.Show("Obeso!");
            }
            else
            {
                MessageBox.Show("IMC Inválido!");
            }
        }
    }
}
